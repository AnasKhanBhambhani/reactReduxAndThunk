import { combineReducers } from "redux";
import UpdateReducer from "./UpdateReducer";

const reducers = combineReducers({
    update : UpdateReducer
})
export default reducers
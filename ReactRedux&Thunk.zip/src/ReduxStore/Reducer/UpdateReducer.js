import { decrement, increment } from './../Action/ActionType';
const UpdateReducer = (count = 0, action) => {
    switch (action.type) {
        case increment:
            return count + action.payload;
        case decrement:
            return count - action.payload;
        default:
            return count
    }
}
export default UpdateReducer
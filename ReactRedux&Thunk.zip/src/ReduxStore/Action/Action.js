import { increment, decrement } from './ActionType';
export const incre = (count) => {
    return async function (dispatch) {
        await dispatch({
            type: increment,
            payload: count
        })
    }
}

export const decre = (count) => {
    return async function (dispatch) {
        await dispatch({
            type: decrement,
            payload: count
        })
    }
}

import React from 'react'
import { bindActionCreators } from 'redux'
import { actionCreators } from '../ReduxStore/Index'
import { connect } from 'react-redux'

const mapDispatchToProps = (dispatch) => {
  return bindActionCreators(actionCreators, dispatch);
};
const Main = ({ incre, decre }) => {
  // const dispatch = useDispatch();
  // const action = bindActionCreators(actionCreators,dispatch)
  return (
    <div>
      {/* <div className='flex justify-center gap-3'>
        <button className='px-4 py-2 bg-emerald-300 rounded ' onClick={()=>{action.incre(1)}}>Increment Count</button>
        <button className='px-4 py-2 bg-emerald-300 rounded ' onClick={()=>{action.decre(1)}}>Decrement Count</button>
      </div> */}
      <div className='flex justify-center gap-3'>
        <button className='px-4 py-2 bg-emerald-300 rounded ' onClick={() => { incre(1) }}>Increment Count</button>
        <button className='px-4 py-2 bg-emerald-300 rounded ' onClick={() => { decre(1) }}>Decrement Count</button>
      </div>
    </div>
  )
}
export default connect(null, mapDispatchToProps)(Main)

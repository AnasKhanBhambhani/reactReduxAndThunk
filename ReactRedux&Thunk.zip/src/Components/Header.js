import React from 'react'
import { connect, useSelector } from 'react-redux'
const mapStateToProps = (state) => {
    return {
        counter: state.update,
    };
};

const Header = ({ counter }) => {
    // const count = useSelector(state=>state.update)
    return (
        <div className='bg-blue-300 p-6 flex justify-between'>
            <div>
                Increment/Decrement
            </div>
            <div>
                {counter}
            </div>
        </div>
    )
}

export default connect(mapStateToProps)(Header)

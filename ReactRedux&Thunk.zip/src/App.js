import './App.css';
import Header from './Components/Header';
import Main from './Components/Main';

function App() {
  return (
    <div className='container bg-orange-500 h-[100vh]  flex gap-8  flex-col'>
      <Header />
      <Main />
    </div>
  );
}

export default App;
